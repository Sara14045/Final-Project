#!/usr/bin/env bash
# Stop on command errors and run from the project root.
set -euo pipefail
cd "$(dirname "$0")"
export PIPENV_VENV_IN_PROJECT=1

# Use the selected Python interpreter to run Pipenv consistently.
PYTHON_BIN="${PYTHON_BIN:-python3}"
if ! "$PYTHON_BIN" -m pipenv --version >/dev/null 2>&1; then
    echo "Install Pipenv first: $PYTHON_BIN -m pip install pipenv" >&2
    exit 1
fi

# Consolidate environment setup, application startup, and automated testing.
case "${1:-help}" in
    setup) "$PYTHON_BIN" -m pipenv sync --dev ;;
    lock) "$PYTHON_BIN" -m pipenv lock ;;
    run) "$PYTHON_BIN" -m pipenv run python main.py ;;
    test) "$PYTHON_BIN" -m pipenv run python -m unittest discover -s tests -v ;;
    *) echo "Usage: bash build.sh {setup|lock|run|test}"; exit 1 ;;
esac
