# Find the source package when this beginner-friendly launcher is run directly.
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
from expense_tracker.__main__ import main


# Start the same application used by the installed package entry point.
if __name__ == "__main__":
    main()
