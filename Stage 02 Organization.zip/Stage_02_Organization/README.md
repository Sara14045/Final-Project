# Expense Tracker: Final Project

This continues the Project 2 console application using simple classes and separate
UI, application logic, and persistence modules. Read `STAGE.md` for this snapshot's
completed features. Later snapshots add MySQL; earlier ones remain file-based.

## Current stage

Stage 2 provides the OOP file-based application, project organization, Pipenv,
a virtual environment setup command, and a Bash command wrapper. Database code
is not connected yet. Future folders contain planning notes only.

## Requirements and setup

Install Python 3.12 and Pipenv. Bash is needed for the supplied scripts (macOS,
Linux, or Git Bash on Windows). Run these commands from the extracted project root:

```bash
python3 -m pip install pipenv
bash build.sh setup
bash build.sh test
bash build.sh run
```

On Windows Git Bash, use `PYTHON_BIN=python bash build.sh setup` if the executable
is named `python`. Use the same setting for other build commands. `setup` creates
an ignored `.venv/` with the versions in `Pipfile.lock`. Do not upload `.venv/`.
After intentionally changing dependencies, run `bash build.sh lock`, then setup.
The project is installed as an editable package through Pipenv. `python main.py`
is also a simple launcher after dependencies are installed.

## Existing features

| Menu | Action |
| --- | --- |
| 1 | Add an expense. |
| 2 | Show all expenses and their total. |
| 3 | Filter by optional inclusive dates and a whole category name. |
| 4 | Save the whole list to JSON. |
| 5 | Open JSON, replacing the list only after successful validation. |
| 6 | Export the whole list as an Excel-compatible CSV. |
| 7 | Exit, with confirmation if session changes are unsaved. |

The program starts empty. Enter dates as `YYYY-MM-DD`; a category and positive
amount are required, while the note is optional. Use one currency consistently.
Blank filter fields mean no restriction. Category matching ignores case and
surrounding spaces. Filtering does not change saved or exported records.

To use your original Project 2 data, put your JSON file in `data/`, choose 5,
and enter `data/expenses.json`. Files without IDs are accepted. Save the new JSON
once to preserve the assigned expense IDs for later database saves.

Amounts use Decimal and round half-up to two cents. The supported amount range
is 0.01 to 9999999999.99, dates are years 1000–9999, categories allow 100
characters, and notes allow 1000. These limits match the planned MySQL columns.
Invalid JSON is rejected without replacing the session. Files may have a UTF-8 BOM.
JSON amounts remain numeric for Project 2 compatibility. CSV has the original
four columns and includes a UTF-8 BOM for Excel. Formula-like text is prefixed
with an apostrophe on CSV export so it is treated as text by spreadsheets.

Save paths are relative to your terminal's current directory. JSON and CSV saves
overwrite the selected file after writing a temporary file successfully. Parent
folders must exist. JSON saving is manual; CSV export does not mark the session
as saved because CSV cannot be reopened by the application.

## Architecture and code map

| Path | Purpose |
| --- | --- |
| `main.py` | Beginner-friendly launcher. |
| `src/expense_tracker/__main__.py` | Application composition and entry point. |
| `src/expense_tracker/ui/console.py` | Prompts, menu, and display only. |
| `src/expense_tracker/services/expense_service.py` | Current list, filters, totals, and storage coordination. |
| `src/expense_tracker/models/expense.py` | Expense and Category classes with shared validation. |
| `src/expense_tracker/persistence/file_storage.py` | JSON and CSV operations. |
| `config/` | Future YAML connection settings. |
| `database/` | Database design and SQL as stages progress. |
| `scripts/` | Database helper scripts as stages progress. |
| `tests/` | Standard-library unittest suite. |
| `docs/TEST_RESULTS.txt` | Actual automated results for this snapshot. |
| `Pipfile` / `Pipfile.lock` | Dependency definitions and locked versions. |
| `pyproject.toml` | Standard src package metadata and entry point. |
| `build.sh` | Consolidated setup, locking, run, and test commands. |
| `data/` | Ignored personal JSON and CSV files. |


