# Group the automated tests.
