# Use temporary folders so tests never change personal expense files.
import csv
import json
import tempfile
import unittest
from decimal import Decimal
from pathlib import Path
from unittest.mock import Mock, patch

from expense_tracker.models.expense import Expense
from expense_tracker.persistence.file_storage import FileStorage
from expense_tracker.services.expense_service import ExpenseService


# Check shared validation, filtering, totals, and partial storage failures.
class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.service = ExpenseService()

    def test_add_and_decimal_total(self):
        self.service.add("2026-11-18", " Food ", "0.10")
        self.service.add("2026-11-18", "Food", "0.20")
        self.assertEqual(self.service.total(), Decimal("0.30"))
        self.assertEqual(self.service.expenses[0].category.name, "Food")

    def test_rounding_and_amount_limits(self):
        self.assertEqual(Expense("2026-11-18", "Food", "1.005").amount, Decimal("1.01"))
        for amount in ["nan", "inf", "0", "-1", "0.001", True, "10000000000", "abc"]:
            with self.subTest(amount=amount), self.assertRaises(ValueError):
                Expense("2026-11-18", "Food", amount)

    def test_invalid_dates_and_fields(self):
        for date in ["2026-02-30", "2026-1-01", "0999-01-01", "bad"]:
            with self.subTest(date=date), self.assertRaises(ValueError):
                Expense(date, "Food", 1)
        for category in ["", " ", "a" * 101]:
            with self.assertRaises(ValueError):
                Expense("2026-11-18", category, 1)
        with self.assertRaises(ValueError):
            Expense("2026-11-18", "Food", 1, "a" * 1001)

    def test_inclusive_filter_does_not_change_list(self):
        self.service.add("2026-11-17", "Travel", 2)
        self.service.add("2026-11-18", "Food", 3)
        self.assertEqual(len(self.service.find("2026-11-18", "2026-11-18", " FOOD ")), 1)
        self.assertEqual(len(self.service.expenses), 2)
        self.assertEqual(len(self.service.find()), 2)
        with self.assertRaises(ValueError):
            self.service.find("2026-11-19", "2026-11-18")

    def test_failed_load_keeps_session(self):
        self.service.add("2026-11-18", "Food", 1)
        with self.assertRaises(OSError):
            self.service.load_file("/missing-expense-tracker-file.json")
        self.assertEqual(len(self.service.expenses), 1)
        self.assertTrue(self.service.changed)

    def test_both_reports_partial_failure(self):
        self.service.database = Mock()
        self.service.database.save.side_effect = ValueError("Offline")
        with patch.object(self.service, "save_file") as save:
            results = self.service.save_both("expenses.json")
        save.assert_called_once_with("expenses.json")
        self.service.database.save.assert_called_once()
        self.assertEqual(results["File"], "Saved.")
        self.assertIn("Failed", results["Database"])
        with patch.object(self.service, "save_file", side_effect=OSError("No space")):
            self.service.database.save.side_effect = None
            results = self.service.save_both("expenses.json")
        self.assertIn("Failed", results["File"])
        self.assertEqual(results["Database"], "Saved.")

    def test_failed_database_load_keeps_session(self):
        self.service.add("2026-11-18", "Food", 1)
        self.service.database = Mock()
        self.service.database.load.side_effect = ValueError("Offline")
        with self.assertRaises(ValueError):
            self.service.load_database()
        self.assertEqual(len(self.service.expenses), 1)


# Verify old and new JSON files, safe replacement, and spreadsheet exports.
class FileTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.path = Path(self.folder.name) / "expenses.json"
        self.storage = FileStorage()
        self.expense = Expense("2026-11-18", "Food", "12.50", "Lunch")

    def test_json_round_trip_preserves_id(self):
        self.storage.save([self.expense], self.path)
        loaded = self.storage.load(self.path)
        self.assertEqual(loaded[0].expense_id, self.expense.expense_id)
        self.assertEqual(loaded[0].amount, Decimal("12.50"))

    def test_project2_json_normalizes_values(self):
        row = {"date": "2026-11-18", "category": " Food ", "amount": 1.239, "note": ""}
        self.path.write_text(json.dumps([row]), encoding="utf-8")
        loaded = self.storage.load(self.path)
        self.assertEqual(loaded[0].category.name, "Food")
        self.assertEqual(loaded[0].amount, Decimal("1.24"))

    def test_invalid_json_and_duplicate_ids_rejected(self):
        for text in ['{}', '[{}]', '[{"amount": NaN}]', 'bad']:
            self.path.write_text(text, encoding="utf-8")
            with self.assertRaises(ValueError):
                self.storage.load(self.path)
        self.storage.save([self.expense, self.expense], self.path)
        with self.assertRaises(ValueError):
            self.storage.load(self.path)

    def test_failed_replace_preserves_previous_file(self):
        self.path.write_text("original", encoding="utf-8")
        with patch("expense_tracker.persistence.file_storage.os.replace", side_effect=OSError("No space")):
            with self.assertRaises(OSError):
                self.storage.save([self.expense], self.path)
        self.assertEqual(self.path.read_text(), "original")
        self.assertEqual(list(self.path.parent.iterdir()), [self.path])

    def test_csv_headers_empty_and_formula_text(self):
        path = self.path.with_suffix(".csv")
        self.storage.export_csv([], path)
        with path.open(encoding="utf-8-sig", newline="") as stream:
            self.assertEqual(len(list(csv.reader(stream))), 1)
        self.expense.note = "=1+1"
        self.storage.export_csv([self.expense], path)
        with path.open(encoding="utf-8-sig", newline="") as stream:
            rows = list(csv.reader(stream))
        self.assertEqual(rows[1][2], "12.50")
        self.assertEqual(rows[1][3], "'=1+1")


if __name__ == "__main__":
    unittest.main()
