# Scripts stage pending

Bash create/drop helpers will be added after the SQL design is reviewed.
