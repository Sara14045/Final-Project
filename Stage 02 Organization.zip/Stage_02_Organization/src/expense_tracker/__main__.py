# Start the file-based menu while the database stages are being developed.
from expense_tracker.ui.console import ExpenseMenu


# Keep importing modules separate from running an interactive session.
def main():
    try:
        ExpenseMenu().run()
    except (KeyboardInterrupt, EOFError):
        print("\nSession ended. Only saved expenses are kept.")


if __name__ == "__main__":
    main()
