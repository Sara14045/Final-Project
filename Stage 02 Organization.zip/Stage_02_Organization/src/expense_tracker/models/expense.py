# Import date and money tools so every storage option uses the same rules.
from datetime import datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from uuid import UUID, uuid4


# Check dates before storing them so text comparisons work correctly.
def valid_date(value):
    if not isinstance(value, str):
        raise ValueError("Date must use YYYY-MM-DD.")
    try:
        parsed = datetime.strptime(value, "%Y-%m-%d")
    except ValueError:
        raise ValueError("Enter a valid date as YYYY-MM-DD.") from None
    if parsed.strftime("%Y-%m-%d") != value or parsed.year < 1000:
        raise ValueError("Use YYYY-MM-DD with a year from 1000 to 9999.")
    return value


# Store one category and remove accidental spaces from its name.
class Category:
    def __init__(self, name):
        if not isinstance(name, str) or not name.strip():
            raise ValueError("Category cannot be empty.")
        self.name = name.strip()
        if len(self.name) > 100:
            raise ValueError("Category must be 100 characters or fewer.")


# Keep expense validation in one class so file and database records agree.
class Expense:
    def __init__(self, date, category, amount, note="", expense_id=None):
        self.date = valid_date(date)
        self.category = Category(category)
        if isinstance(amount, bool) or not isinstance(amount, (str, int, float, Decimal)):
            raise ValueError("Enter a positive numeric amount.")
        try:
            number = Decimal(str(amount))
            if not number.is_finite() or number <= 0 or number > Decimal("9999999999.99"):
                raise ValueError("Amount must be from 0.01 to 9999999999.99.")
            self.amount = number.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        except InvalidOperation:
            raise ValueError("Enter a valid amount.") from None
        if self.amount < Decimal("0.01"):
            raise ValueError("Amount must be at least 0.01 after rounding.")
        if not isinstance(note, str) or len(note.strip()) > 1000:
            raise ValueError("Note must be text of 1000 characters or fewer.")
        self.note = note.strip()
        if expense_id is None:
            self.expense_id = str(uuid4())
        else:
            try:
                self.expense_id = str(UUID(expense_id))
            except (ValueError, TypeError, AttributeError):
                raise ValueError("Expense ID must be a valid UUID.") from None

    # Keep old JSON fields and add an ID to prevent duplicate database saves.
    def to_dict(self):
        return {
            "date": self.date,
            "category": self.category.name,
            "amount": float(self.amount),
            "note": self.note,
            "expense_id": self.expense_id,
        }

    # Accept old Project 2 records without an ID and validate every field.
    @classmethod
    def from_dict(cls, row):
        if not isinstance(row, dict):
            raise ValueError("Each expense must be an object.")
        required = ("date", "category", "amount", "note")
        if any(key not in row for key in required):
            raise ValueError("An expense is missing required fields.")
        if "expense_id" in row and not isinstance(row["expense_id"], str):
            raise ValueError("Expense ID must be text.")
        if isinstance(row["amount"], str):
            raise ValueError("JSON amounts must be numbers.")
        return cls(row["date"], row["category"], row["amount"], row["note"], row.get("expense_id"))
