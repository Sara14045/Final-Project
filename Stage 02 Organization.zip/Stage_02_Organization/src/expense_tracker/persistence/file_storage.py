# Use standard libraries for portable files and safe replacement of old saves.
import csv
import json
import os
import tempfile
from decimal import Decimal
from pathlib import Path

from expense_tracker.models.expense import Expense


# Keep all file access outside the menu and expense service.
class FileStorage:
    # Write a temporary file first so a failed save does not truncate the old file.
    def _write(self, filename, encoding, writer):
        if not str(filename).strip():
            raise ValueError("Enter a file name.")
        target = Path(filename)
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(mode="w", encoding=encoding, newline="",
                                             dir=target.parent, delete=False) as stream:
                temporary = Path(stream.name)
                writer(stream)
            os.replace(temporary, target)
        finally:
            if temporary is not None and temporary.exists():
                temporary.unlink()

    # Save the whole list with stable IDs while keeping Project 2 field names.
    def save(self, expenses, filename):
        self._write(filename, "utf-8", lambda stream: json.dump(
            [expense.to_dict() for expense in expenses], stream, indent=4, allow_nan=False))

    # Build a new list completely before the service replaces existing expenses.
    def load(self, filename):
        with open(filename, encoding="utf-8-sig") as stream:
            rows = json.load(stream, parse_float=Decimal)
        if not isinstance(rows, list):
            raise ValueError("The JSON file must contain a list.")
        expenses = [Expense.from_dict(row) for row in rows]
        ids = [expense.expense_id for expense in expenses]
        if len(ids) != len(set(ids)):
            raise ValueError("The file contains duplicate expense IDs.")
        return expenses

    # Export text fields safely for spreadsheet use, including empty lists.
    def export_csv(self, expenses, filename):
        def safe_text(value):
            if value.lstrip().startswith(("=", "+", "-", "@")):
                return "'" + value
            return value

        def write_rows(stream):
            writer = csv.writer(stream)
            writer.writerow(["Date", "Category", "Amount", "Note"])
            for expense in expenses:
                writer.writerow([expense.date, safe_text(expense.category.name),
                                 str(expense.amount), safe_text(expense.note)])

        self._write(filename, "utf-8-sig", write_rows)
