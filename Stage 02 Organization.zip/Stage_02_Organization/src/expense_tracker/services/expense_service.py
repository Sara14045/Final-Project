# Keep calculations exact and share the model's date validation.
from decimal import Decimal

from expense_tracker.models.expense import Expense, valid_date
from expense_tracker.persistence.file_storage import FileStorage


# Coordinate expenses without reading input or printing menu messages.
class ExpenseService:
    def __init__(self, database=None):
        self.expenses = []
        self.files = FileStorage()
        self.database = database
        self.changed = False

    # Add a validated expense to the current session.
    def add(self, date, category, amount, note=""):
        expense = Expense(date, category, amount, note)
        self.expenses.append(expense)
        self.changed = True
        return expense

    # Match optional inclusive dates and a whole category name.
    def find(self, start="", end="", category=""):
        if start:
            valid_date(start)
        if end:
            valid_date(end)
        if start and end and start > end:
            raise ValueError("Start date cannot be after end date.")
        category = category.strip().casefold()
        return [expense for expense in self.expenses
                if (not start or expense.date >= start)
                and (not end or expense.date <= end)
                and (not category or expense.category.name.casefold() == category)]

    # Sum Decimal values so cents do not accumulate floating-point errors.
    def total(self, expenses=None):
        if expenses is None:
            expenses = self.expenses
        return sum((expense.amount for expense in expenses), Decimal("0.00"))

    # Save JSON and mark changes as kept only after the write succeeds.
    def save_file(self, filename):
        self.files.save(self.expenses, filename)
        self.changed = False

    # Replace the current list only after the whole file has been validated.
    def load_file(self, filename):
        loaded = self.files.load(filename)
        self.expenses = loaded
        self.changed = False

    # Export every expense rather than the last filtered view.
    def export_csv(self, filename):
        self.files.export_csv(self.expenses, filename)

    # Require a database object only when database storage is requested.
    def save_database(self):
        if self.database is None:
            raise ValueError("Database storage is not available in this stage.")
        count = self.database.save(self.expenses)
        self.changed = False
        return count

    # Preserve current data if loading from the database fails.
    def load_database(self):
        if self.database is None:
            raise ValueError("Database storage is not available in this stage.")
        loaded = self.database.load()
        self.expenses = loaded
        self.changed = False

    # Attempt both destinations separately and report any partial failure.
    def save_both(self, filename):
        results = {}
        for name, action in [("File", lambda: self.save_file(filename)),
                             ("Database", self.save_database)]:
            try:
                action()
                results[name] = "Saved."
            except (OSError, ValueError) as error:
                results[name] = "Failed: " + str(error)
        return results
