# Import only the service so prompts stay separate from storage code.
from expense_tracker.services.expense_service import ExpenseService


# Present the existing actions and optional database storage choices.
class ExpenseMenu:
    def __init__(self, service=None):
        self.service = service if service is not None else ExpenseService()

    # Print a list and its total without changing the current session.
    def show(self, expenses):
        if not expenses:
            print("No expenses found.")
            return
        for expense in expenses:
            print(f"{expense.date} | {expense.category.name} | {expense.amount:.2f} | {expense.note}")
        print(f"Total: {self.service.total(expenses):.2f}")

    # Warn before replacing unsaved session data.
    def can_replace(self):
        if not self.service.changed:
            return True
        return input("Unsaved changes will be replaced. Continue? (y/n): ").strip().lower() == "y"

    # Repeat the menu and catch expected input and storage errors.
    def run(self):
        while True:
            print("\nExpense Tracker")
            print("1. Add expense\n2. Show expenses\n3. Filter expenses")
            print("4. Save JSON\n5. Open JSON\n6. Export CSV\n7. Exit")
            if self.service.database is not None:
                print("8. Save database\n9. Open database\n10. Save both JSON and database")
            choice = input("Choose an option: ").strip()
            try:
                if choice == "1":
                    self.service.add(input("Date (YYYY-MM-DD): ").strip(),
                                     input("Category: ").strip(), input("Amount: ").strip(),
                                     input("Note (optional): ").strip())
                    print("Expense added.")
                elif choice == "2":
                    self.show(self.service.expenses)
                elif choice == "3":
                    rows = self.service.find(input("Start date (blank for any): ").strip(),
                                             input("End date (blank for any): ").strip(),
                                             input("Category (blank for all): ").strip())
                    self.show(rows)
                elif choice == "4":
                    self.service.save_file(input("JSON file name: ").strip())
                    print("Expenses saved to JSON.")
                elif choice == "5":
                    if self.can_replace():
                        self.service.load_file(input("JSON file to open: ").strip())
                        print("Expenses opened. Current list replaced.")
                elif choice == "6":
                    self.service.export_csv(input("CSV file name: ").strip())
                    print("CSV exported.")
                elif choice == "7":
                    if self.service.changed:
                        answer = input("Unsaved changes will be lost. Exit? (y/n): ").strip().lower()
                        if answer != "y":
                            continue
                    print("Goodbye! Only saved expenses are kept.")
                    return
                elif choice == "8" and self.service.database is not None:
                    count = self.service.save_database()
                    print(f"Database saved: {count} expenses.")
                elif choice == "9" and self.service.database is not None:
                    if self.can_replace():
                        self.service.load_database()
                        print("Database opened. Current list replaced.")
                elif choice == "10" and self.service.database is not None:
                    results = self.service.save_both(input("JSON file name: ").strip())
                    for name, message in results.items():
                        print(f"{name}: {message}")
                else:
                    print("Please choose one of the displayed options.")
            except (OSError, ValueError, OverflowError) as error:
                print(f"Could not complete the action: {error}")
