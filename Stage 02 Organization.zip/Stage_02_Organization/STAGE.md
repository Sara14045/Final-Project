# Stage 2: organization

Organize the project, move the existing file features into simple OOP tiers, and set up Pipenv and build.sh.

