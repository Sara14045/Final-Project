# Database stage pending

The next stage will define related categories and expenses tables and add schema.sql.
