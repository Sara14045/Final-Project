# Changes from the previous stage

Stage 1 starts the delivered sequence; compare it against your existing Project 2 repository before copying.

## Added

- `.gitignore`
- `README.md`
- `STAGE.md`
- `config/README.md`
- `data/README.md`
- `database/README.md`
- `docs/TEST_RESULTS.txt`
- `legacy/README.md`
- `legacy/expenses.py`
- `legacy/files.py`
- `legacy/main.py`
- `scripts/README.md`
- `src/expense_tracker/__init__.py`
- `src/expense_tracker/models/__init__.py`
- `src/expense_tracker/persistence/__init__.py`
- `src/expense_tracker/services/__init__.py`
- `src/expense_tracker/ui/__init__.py`
- `tests/README.md`

## Changed

None.

## Removed

None.

