# Testing plan

At each stage, test the new behavior before the next commit. Add automated tests as the service and persistence modules are implemented. A real MAMP MySQL connection must be tested separately; mocked tests cannot prove it works.
