# Stage 1: structure and README

Preserve the runnable Project 2 baseline in legacy/ and reserve the future tier folders.
Run `python legacy/main.py`.


