# Database work planned

The next design stage will define categories and expenses with a foreign key from expenses to categories. SQL scripts, field types, constraints, and reset behavior have not been implemented yet.
