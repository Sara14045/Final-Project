# Configuration

The connection stage will add `database.example.yaml` and read local connection settings from `database.yaml` using PyYAML. No credentials or connection code are included yet.
