from expenses import add, show, find  
from files import save, load, export  

# Show the menu and keep the expense list.
def main():  
    data = []  
    while True:  
        print("\nExpense Tracker")  
        print("1. Add expense")  
        print("2. Show expenses")  
        print("3. Filter expenses")  
        print("4. Save JSON")  
        print("5. Open JSON")  
        print("6. Export CSV")  
        print("7. Exit")  
        ch = input("Choose 1 to 7: ").strip()  
        if ch == "1":  
            add(data)  
        elif ch == "2":  
            show(data)  
        elif ch == "3":  
            find(data)  
        elif ch == "4":  
            save(data)  
        elif ch == "5":  
            new = load()  
            if new is not None:  
                data = new  
        elif ch == "6":  
            export(data)  
        elif ch == "7":  
            print("Goodbye! Only saved expenses are kept.")  
            break  
        else:  
            print("Please choose 1 to 7.")  

if __name__ == "__main__":  
    main()  
