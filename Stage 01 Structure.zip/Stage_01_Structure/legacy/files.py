import json  
import csv  
import math  
from datetime import datetime  

# Save the expense list to a JSON file.
def save(data):  
    name = input("File to save (example: expenses.json): ").strip()  
    try:  
        with open(name, "w", encoding="utf-8") as f:  
            json.dump(data, f, indent=4)  
        print("Expenses saved.")  
    except OSError:  
        print("Could not save that file.")  

# Open a JSON file and check its expenses.
def load():  
    name = input("File to open: ").strip()  
    try:  
        with open(name, "r", encoding="utf-8") as f:  
            data = json.load(f)  
        if not isinstance(data, list):  
            raise ValueError  
        for e in data:  
            if not isinstance(e, dict):  
                raise ValueError  
            d = e.get("date")  
            c = e.get("category")  
            a = e.get("amount")  
            n = e.get("note")  
            if not isinstance(d, str):  
                raise ValueError  
            x = datetime.strptime(d, "%Y-%m-%d")  
            if x.strftime("%Y-%m-%d") != d:  
                raise ValueError  
            if not isinstance(c, str) or not c.strip():  
                raise ValueError  
            if type(a) not in (int, float):  
                raise ValueError  
            if not math.isfinite(a) or a <= 0:  
                raise ValueError  
            if not isinstance(n, str):  
                raise ValueError  
        print("Expenses opened. Current list replaced.")  
        return data  
    except (OSError, ValueError, UnicodeError, OverflowError):  
        print("Could not open a valid expense file.")  
        return None  

# Export all current expenses to a CSV file for Excel.
def export(data):  
    name = input("CSV file name (example: expenses.csv): ").strip()  
    try:  
        with open(name, "w", newline="", encoding="utf-8-sig") as f:  
            w = csv.writer(f)  
            w.writerow(["Date", "Category", "Amount", "Note"])  
            for e in data:  
                w.writerow([e["date"], e["category"], f"{e['amount']:.2f}", e["note"]])  
        print("CSV exported.")  
    except OSError:  
        print("Could not export that file.")  
