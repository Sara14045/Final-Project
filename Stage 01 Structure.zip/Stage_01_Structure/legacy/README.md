# Working Project 2 baseline

Run `python legacy/main.py` from the project root. Only upload suffixes and inline explanatory comments were removed. Behavior is preserved. These functions still mix prompts and logic; they will be moved into the planned tiers gradually.
