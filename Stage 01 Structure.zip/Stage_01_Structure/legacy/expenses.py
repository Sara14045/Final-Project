from datetime import datetime  
import math  

# Ask for expense details and add them to the list.
def add(data):  
    d = input("Date (YYYY-MM-DD): ").strip()  
    try:  
        x = datetime.strptime(d, "%Y-%m-%d")  
        if x.strftime("%Y-%m-%d") != d:  
            raise ValueError  
    except ValueError:  
        print("Enter a valid date as YYYY-MM-DD.")  
        return  
    c = input("Category: ").strip()  
    if c == "":  
        print("Category cannot be empty.")  
        return  
    try:  
        a = float(input("Amount: "))  
    except ValueError:  
        print("Enter a number.")  
        return  
    if not math.isfinite(a) or a <= 0:  
        print("Enter a positive number.")  
        return  
    a = round(a, 2)  
    if a == 0:  
        print("Amount must be at least 0.01.")  
        return  
    n = input("Note (optional): ").strip()  
    e = {"date": d, "category": c, "amount": a, "note": n}  
    data.append(e)  
    print("Expense added.")  

# Print each expense and the total amount.
def show(data):  
    if not data:  
        print("No expenses yet.")  
        return  
    total = 0  
    for e in data:  
        print(f"{e['date']} | {e['category']} | {e['amount']:.2f} | {e['note']}")  
        total = total + e["amount"]  
    print(f"Total: {total:.2f}")  

# Print expenses matching dates, a category, or both.
def find(data):  
    s = input("Start date (YYYY-MM-DD, blank for any): ").strip()  
    t = input("End date (YYYY-MM-DD, blank for any): ").strip()  
    c = input("Category (blank for all): ").strip().lower()  
    try:  
        for d in [s, t]:  
            if d:  
                x = datetime.strptime(d, "%Y-%m-%d")  
                if x.strftime("%Y-%m-%d") != d:  
                    raise ValueError  
    except ValueError:  
        print("Enter valid dates as YYYY-MM-DD.")  
        return  
    if s and t and s > t:  
        print("Start date cannot be after end date.")  
        return  
    rows = []  
    for e in data:  
        if s and e["date"] < s:  
            continue  
        if t and e["date"] > t:  
            continue  
        if c and e["category"].lower() != c:  
            continue  
        rows.append(e)  
    if not rows:  
        print("No matching expenses.")  
        return  
    show(rows)  
