# Database scripts planned

Bash scripts to create and drop the MySQL database will be added after the schema is designed. They must read the intended configuration and clearly identify destructive operations.
