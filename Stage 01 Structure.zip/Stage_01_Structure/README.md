# Final Project: Expense Tracker with MySQL

## Current milestone: project structure and documentation

This project continues the Project 2 console Expense Tracker. This first milestone
organizes the project and documents the development plan. The working file-based
application is preserved in `legacy/` so it can still be demonstrated while
Project 3 is built in small, tested steps.

**MySQL storage, OOP classes, YAML loading, Pipenv setup, `build.sh`, and database
scripts are planned work. They are not implemented or tested in this milestone.**
The `src` packages are scaffolding, not a finished multi-tier application.

## Run the existing application

Use Python 3.6 or newer for the preserved baseline; it has no third-party dependencies.
The Python version for the final application will be confirmed during Pipenv setup.

Extract the archive, open a terminal, and run:

```bash
python legacy/main.py
```

Use `python3` instead of `python` if required on your computer.
The application starts with an empty expense list. To use your existing data,
copy your JSON file into `data/`, select option 5, and enter `data/expenses.json`.
File paths are relative to the terminal's current folder.

| Option | Existing behavior |
| --- | --- |
| 1 | Add an expense with a date, category, positive amount, and optional note. |
| 2 | Show all expenses and their total. |
| 3 | Filter by inclusive date range, category, or both. |
| 4 | Save the current list to JSON. |
| 5 | Open JSON and replace the current list after validation. |
| 6 | Export all current expenses to CSV for Excel. |
| 7 | Exit. Unsaved changes are lost. |

Dates use `YYYY-MM-DD`. Category searches match the whole name and ignore case.
Blank filter fields impose no restriction. Adding expenses rounds amounts to two
decimal places. Saving and exporting overwrite an existing file of the same name.
CSV export includes all expenses, even after a filtered display. Use one currency.

## Folder structure

| Location | Purpose |
| --- | --- |
| `README.md` | Setup, current status, architecture, and development plan. |
| `.gitignore` | Exclude generated files, local credentials, and personal data. |
| `legacy/main.py` | Working original menu and entry point. |
| `legacy/expenses.py` | Original add, display, and filter functions. |
| `legacy/files.py` | Original JSON and CSV functions. |
| `src/expense_tracker/ui/` | Future console prompts, menu, and output. |
| `src/expense_tracker/services/` | Future validation, filtering, totals, and storage coordination. |
| `src/expense_tracker/models/` | Future simple `Expense` and `Category` classes. |
| `src/expense_tracker/persistence/` | Future file and MySQL storage classes. |
| `config/` | Future YAML connection template and ignored local settings. |
| `database/` | Future schema and database design documentation. |
| `scripts/` | Future Bash create/drop database scripts. |
| `tests/` | Future automated tests for each implemented stage. |
| `data/` | Local JSON and CSV files; personal data is not bundled. |

`Pipfile`, `Pipfile.lock`, and root `build.sh` will be added in the environment
setup stage. An empty package currently contains only an explanatory comment.

## Planned multi-tier architecture

The UI will call an expense service. The service will use model objects and
persistence classes. Persistence classes will handle files or MySQL without
prompting the user. SQL will stay out of the menu and business logic.

| Tier | Planned responsibility | Planned simple classes |
| --- | --- | --- |
| Presentation | Read input and display messages. | `ExpenseMenu` |
| Application | Validate expenses, filter records, calculate totals, and coordinate saves. | `ExpenseService` |
| Persistence | Read and write JSON/CSV or MySQL records. | `FileStorage`, `DatabaseStorage` |
| Shared models | Represent expense and category information. | `Expense`, `Category` |

The original functions mix input and application logic. They remain in `legacy/`
until each replacement tier is tested. The final application will use the new
package; maintaining two separate applications is not the goal.

## Planned database and storage behavior

MAMP or MAMP PRO will provide MySQL. The database design stage will define two
related tables: `categories` and `expenses`. Each expense will reference one
category; one category can be used by many expenses. Field types, keys, and
constraints will be decided and documented before SQL implementation.

The final save menu will offer file, database, or both. JSON open/save and CSV
export will remain available. The database stage will also provide loading from
MySQL. Before implementing it, define how repeated saves avoid duplicates and
whether database loading replaces the current list. Saving to both must report
the outcome of each destination, including partial failures.

Database connection settings will be read from YAML with PyYAML. A committed
example configuration will show required fields without real credentials. Each
user will keep actual MAMP host, port, database, username, and password in ignored
`config/database.yaml`. MAMP settings must be checked locally rather than assumed.

## Environment and command plan

The environment stage will use Pipenv and a project virtual environment. It will
add and lock the required packages, including PyYAML and a MySQL driver. A Bash
`build.sh` will consolidate setup, run, and test commands. Separate Bash scripts
will create and drop the database. Those commands do not exist in this milestone.



