# Local expense files

Save JSON and CSV files here. Uploaded personal expense data is not included in this archive. To use it, copy existing files here and open `data/expenses.json` from the menu.
